# AutoCall Scheduler (Android / Java)

A small Android Studio starter project for scheduling a daily outgoing call.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the APK on your phone.
5. Grant Phone permission, Notifications permission, and Android's **Alarms & reminders** special access.

## Use
Enter the phone number, choose the time, and tap **Save and enable daily call**.
Tap **Disable schedule** to stop it.

## Important Android limitation
This project uses an exact alarm and attempts to launch `ACTION_CALL` at the scheduled time. Modern Android versions restrict background activity launches. If Android blocks the automatic call launch, the app posts a notification with a **Call** action; tapping it places the call. Therefore, unattended calls while the phone is locked are not guaranteed on stock Android 14/15. Test carefully with a number you control.

The app does not record calls, answer calls, or bypass Android security. Carrier charges may apply.

## Build remotely without a PC (GitHub Actions)
1. Create a new **public** repository on GitHub (for example `AutoCallScheduler`).
2. Extract this ZIP on your Android phone.
3. Upload the project files and folders to the repository's `main` branch, keeping their folder paths. Include the hidden `.github/workflows/build-apk.yml` file.
4. On GitHub, open the repository's **Actions** tab, select **Build AutoCall Scheduler APK**, then tap **Run workflow**.
5. When the run finishes successfully, open that run and download the artifact named `AutoCallScheduler-debug-apk`.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

GitHub's hosted runner performs the compilation. The repository must include the workflow file for the Actions tab to show the workflow. A debug APK is unsigned for Play Store distribution but can be installed directly after allowing installs from that browser/files app.
