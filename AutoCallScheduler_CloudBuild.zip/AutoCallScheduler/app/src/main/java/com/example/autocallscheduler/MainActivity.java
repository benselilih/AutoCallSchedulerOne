package com.example.autocallscheduler;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends Activity {
    public static final String PREFS = "autocall_prefs";
    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_NUMBER = "number";
    public static final String KEY_HOUR = "hour";
    public static final String KEY_MINUTE = "minute";

    private EditText numberInput;
    private TimePicker timePicker;
    private CheckBox dailyCheck;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 36, 32, 24);

        TextView heading = new TextView(this);
        heading.setText("AutoCall Scheduler");
        heading.setTextSize(24);
        root.addView(heading);

        TextView info = new TextView(this);
        info.setText("Set a phone number and time for a daily scheduled call.");
        info.setTextSize(16);
        add(root, info);

        numberInput = new EditText(this);
        numberInput.setHint("Phone number, e.g. 0550123456");
        numberInput.setInputType(3);
        numberInput.setText(p.getString(KEY_NUMBER, ""));
        add(root, numberInput);

        timePicker = new TimePicker(this);
        timePicker.setIs24HourView(true);
        timePicker.setHour(p.getInt(KEY_HOUR, 8));
        timePicker.setMinute(p.getInt(KEY_MINUTE, 0));
        add(root, timePicker);

        dailyCheck = new CheckBox(this);
        dailyCheck.setText("Repeat every day");
        dailyCheck.setChecked(true);
        add(root, dailyCheck);

        Button save = new Button(this);
        save.setText("Save and enable daily call");
        add(root, save);
        save.setOnClickListener(v -> saveSchedule());

        Button stop = new Button(this);
        stop.setText("Disable schedule");
        add(root, stop);
        stop.setOnClickListener(v -> {
            cancelAlarm();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean(KEY_ENABLED, false).apply();
            Toast.makeText(this, "Schedule disabled", Toast.LENGTH_SHORT).show();
        });

        TextView warning = new TextView(this);
        warning.setText("\nAndroid may prevent an app from starting a phone call while it is in the background or the phone is locked. If that happens, a notification will appear and you can tap Call. Test before relying on it.");
        warning.setTextSize(14);
        add(root, warning);

        setContentView(root);
        requestPermissionsIfNeeded();
    }

    private void add(LinearLayout root, android.view.View view) {
        root.addView(view, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 11);
        }
    }

    private void saveSchedule() {
        String number = numberInput.getText().toString().trim();
        if (number.isEmpty()) {
            numberInput.setError("Enter a phone number");
            return;
        }
        int hour = timePicker.getHour();
        int minute = timePicker.getMinute();

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        p.edit().putString(KEY_NUMBER, number)
                .putInt(KEY_HOUR, hour).putInt(KEY_MINUTE, minute)
                .putBoolean(KEY_ENABLED, true).apply();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                new AlertDialog.Builder(this)
                        .setTitle("Allow exact alarms")
                        .setMessage("Android needs permission to run the call schedule at the exact time. Enable 'Alarms & reminders' for AutoCall Scheduler.")
                        .setPositiveButton("Open settings", (d, w) ->
                                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                        Uri.parse("package:" + getPackageName()))))
                        .setNegativeButton("Cancel", null).show();
                return;
            }
        }

        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Grant Phone permission, then press Save again.", Toast.LENGTH_LONG).show();
            return;
        }
        scheduleNext(this);
        Toast.makeText(this, "Daily call scheduled", Toast.LENGTH_LONG).show();
    }

    public static void scheduleNext(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean(KEY_ENABLED, false)) return;

        Calendar now = Calendar.getInstance();
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, p.getInt(KEY_HOUR, 8));
        next.set(Calendar.MINUTE, p.getInt(KEY_MINUTE, 0));
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (!next.after(now)) next.add(Calendar.DAY_OF_YEAR, 1);

        AlarmManager am = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, 1001, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
        }
    }

    public static void cancelAlarm(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, 1001, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
    }

    private void cancelAlarm() { cancelAlarm(this); }
}
