package com.example.autocallscheduler;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "scheduled_calls";

    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences p = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        if (!p.getBoolean(MainActivity.KEY_ENABLED, false)) return;

        String number = p.getString(MainActivity.KEY_NUMBER, "");
        if (number == null || number.trim().isEmpty()) return;

        // Schedule tomorrow first, so the daily schedule survives even if call launching is blocked.
        MainActivity.scheduleNext(context);

        Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null));
        callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        boolean launched = false;
        if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            try {
                context.startActivity(callIntent);
                launched = true;
            } catch (Exception ignored) {
                // Android may block background activity launches. Show a user-tappable call notification.
            }
        }
        if (!launched) showCallNotification(context, callIntent);
    }

    private void showCallNotification(Context context, Intent callIntent) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Scheduled calls",
                    NotificationManager.IMPORTANCE_HIGH));
        }
        PendingIntent callPending = PendingIntent.getActivity(context, 1002, callIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(context, CHANNEL)
                : new android.app.Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.sym_action_call)
                .setContentTitle("Scheduled call")
                .setContentText("Tap Call to place your scheduled call.")
                .setCategory(android.app.Notification.CATEGORY_CALL)
                .setAutoCancel(true)
                .setContentIntent(callPending)
                .addAction(android.R.drawable.sym_action_call, "Call", callPending);
        nm.notify(1003, builder.build());
    }
}
